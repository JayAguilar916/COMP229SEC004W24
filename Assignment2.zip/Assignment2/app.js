const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const productController = require('./productController');

const app = express();

//Middleware
app.use(cors());
app.use(express.json());

//MongoDB connection
mongoose.connect('mongodb://localhost:27017/Marketplace')
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch(err => {
        console.error('Error connecting to MongoDB:', err.message);
    });

//Route for root URL
app.get('/', (req, res) => {
    res.json({ message: "Welcome to MovieStore application." });
});

//Route definitions for CRUD operations
app.get('/api/products', productController.getAllProducts);
app.get('/api/products/search', productController.findProductsByName);
app.get('/api/products/:id', productController.getProductById);
app.post('/api/products', productController.addProduct);
app.put('/api/products/:id', productController.updateProductById);
app.delete('/api/products/:id', productController.deleteProductById);
app.delete('/api/products/', productController.deleteAllProducts);

//Start the server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
